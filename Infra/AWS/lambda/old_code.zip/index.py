import boto3
import random

dynamodb = boto3.client('dynamodb')


def lambda_handler(event, context):
 
      customerid = 'cust' + str(random.randrange(1,999))
      dynamodb.put_item(TableName='customer', Item={"CustomerID": {"S": customerid },"CustomerName": {"S": "Mario"},"Date": {"S": "13-12-2022"}})
      client = boto3.client('codecommit')
      commit_id = client.get_branch(
      repositoryName='openHAB',
      branchName='main')['branch']['commitId']

      print('Alok sharma  debug: ' + commit_id)
      client.create_branch( repositoryName='openHAB', branchName= customerid  , commitId= commit_id )